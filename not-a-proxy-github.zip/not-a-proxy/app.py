from flask import Flask, request, jsonify, send_from_directory, Response
import requests, json, base64, socket, ipaddress, re, logging
from urllib.parse import urljoin, quote
from bs4 import BeautifulSoup
from urllib.parse import urlparse,parse_qs
app=Flask(__name__,static_folder='.',static_url_path='/static')
HEAD={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36'}
def clean_url(url):
 try:
  p=urlparse(url)
  if 'bing.com' in p.netloc and p.path=='/ck/a':
   u=parse_qs(p.query).get('u',[''])[0]
   if u.startswith('a1'): return base64.urlsafe_b64decode(u[2:]+'===').decode()
 except: pass
 return url
@app.route('/')
def index(): return send_from_directory('.', 'index.html')
@app.route('/api/search')
def search():
 q=request.args.get('q','').strip()[:300]; kind=request.args.get('type','web')
 if not q: return jsonify(results=[])
 if kind not in ['web','images','videos']: return jsonify(error='Invalid search type'),400
 path={'web':'search','images':'images/search','videos':'videos/search'}[kind]
 try:
  r=requests.get('https://www.bing.com/'+path,params={'q':q,'count':24},headers=HEAD,timeout=20); r.raise_for_status(); s=BeautifulSoup(r.text,'html.parser'); out=[]
  if kind=='web':
   for el in s.select('li.b_algo'):
    a=el.select_one('h2 a'); desc=el.select_one('.b_caption p') or el.select_one('p')
    if a and a.get('href'): out.append({'title':a.get_text(' ',strip=True),'url':clean_url(a['href']),'description':desc.get_text(' ',strip=True) if desc else ''})
  elif kind=='images':
   for a in s.select('a.iusc[m]'):
    try:
     m=json.loads(a['m']); out.append({'title':m.get('t','Image result'),'url':m.get('purl') or m.get('murl'),'image':m.get('turl') or m.get('murl')})
    except: continue
  else:
   for el in s.select('.mc_vtvc[mmeta]'):
    try:
     m=json.loads(el['mmeta']); img=el.select_one('img'); a=el.select_one('a[aria-label]'); title=img.get('alt','') if img else ''
     out.append({'title':title or (a.get('aria-label','Video result') if a else 'Video result'),'url':m.get('murl') or m.get('pgurl'),'image':(img.get('data-src-hq') or img.get('src') or m.get('turl')) if img else m.get('turl'),'description':a.get('aria-label','') if a else ''})
    except: continue
  return jsonify(results=out)
 except Exception as e: return jsonify(error='Search is temporarily unavailable. Please try again.'),502
def public_url(url):
 try:
  p=urlparse(url)
  if p.scheme not in ('http','https') or not p.hostname or p.username or p.password: return False
  for item in socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme=='https' else 80), type=socket.SOCK_STREAM):
   if not ipaddress.ip_address(item[4][0]).is_global: return False
  return True
 except: return False

def proxied(url, base):
 url=urljoin(base,url)
 return '/proxy?url='+quote(url,safe='') if urlparse(url).scheme in ('http','https') else url

@app.route('/proxy', methods=['GET','POST'])
def proxy():
 url=request.args.get('url','')
 try:
  for _ in range(6):
   if not public_url(url): return Response('This address cannot be opened.',status=403)
   r=requests.request(request.method,url,headers=HEAD,params=None,data=request.form if request.method=='POST' else None,timeout=20,allow_redirects=False,stream=True)
   if r.is_redirect:
    url=urljoin(url,r.headers.get('Location','')); continue
   break
  else: return Response('Too many redirects.',status=502)
  ctype=r.headers.get('Content-Type','')
  if 'text/html' in ctype:
   r.encoding=r.encoding or 'utf-8'; soup=BeautifulSoup(r.text,'html.parser')
   base=soup.find('base',href=True); base_url=urljoin(url,base['href']) if base else url
   if base: base.decompose()
   for tag in soup.find_all(True):
    for attr in ('href','src','action','poster'):
     val=tag.get(attr)
     if val and not val.startswith(('#','data:','javascript:','mailto:','tel:')): tag[attr]=proxied(val,base_url)
    if tag.get('srcset'):
     tag['srcset']=', '.join(proxied(part.strip().split(' ')[0],base_url)+' '+ ' '.join(part.strip().split(' ')[1:]) for part in tag['srcset'].split(','))
    if tag.name=='a': tag.attrs.pop('target',None)
    if tag.name=='meta' and tag.get('http-equiv','').lower() in ('content-security-policy','x-frame-options'): tag.decompose()
   content=str(soup).encode('utf-8'); ctype='text/html; charset=utf-8'
  elif 'text/css' in ctype:
   text=r.content.decode('utf-8',errors='replace')
   text=re.sub(r'url\((?!["\']?data:)(["\']?)([^)"\']+)\1\)',lambda m:'url("'+proxied(m.group(2),url)+'")',text)
   content=text.encode(); ctype='text/css; charset=utf-8'
  else:
   content=r.raw.read(12000000,decode_content=True)
  return Response(content,status=r.status_code,headers={'Content-Type':ctype or 'application/octet-stream','Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'})
 except Exception:
  return Response('Could not load this site. It may block proxy access or be temporarily unavailable.',status=502)
if __name__=='__main__':
 logging.getLogger('werkzeug').disabled=True
 app.run(host='0.0.0.0',port=3000)
