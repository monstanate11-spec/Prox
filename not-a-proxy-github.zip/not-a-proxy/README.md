# Not a Proxy

A cyberpunk-inspired search interface with web, image, and video results and a tabbed, best-effort website viewer. Search results are retrieved from Bing.

## Run locally

Requires Python 3.9 or newer.

```bash
git clone https://github.com/YOUR-USERNAME/not-a-proxy.git
cd not-a-proxy
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open `http://localhost:3000`. The built-in Flask server is for development, not production.

## Using it

- Search the web, images, or videos; click a result to open it in the viewer.
- Use the tab strip to switch between search and open websites. Add a tab with **+**, enter a URL in the address bar, and press Enter.
- Press `/` to focus search, or Ctrl/Cmd+T to open a tab while viewing a site.

## Important limitations

- The viewer is a simple HTML-rewriting proxy, not a full web browser. Many sites, logins, videos, and JavaScript-heavy applications may not work. Use **Open original** when needed.
- This app does not save search or tab history and disables Flask's request logging. This does **not** provide anonymity or guarantee that activity is not recorded: the browser, hosting infrastructure, network, Bing, and websites may retain data. Opening the original site may create browser history.
- Search depends on Bing's page format and may break if it changes or blocks requests.
- The proxy is a prototype. Do not expose it to the public internet or use it with sensitive accounts without a security review, authentication, rate limiting, and appropriate network isolation.
- The background is AI-generated artwork.
